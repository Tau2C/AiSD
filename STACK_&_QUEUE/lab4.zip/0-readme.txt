To jest projekt dla studentów, bez implementacji funkcji.
