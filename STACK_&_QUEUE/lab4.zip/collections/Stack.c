#include <stdio.h>
#include <stdlib.h>
#include "Stack.h"

EXC_DEFINE(stack_function_not_implemented, EXC_NUM_USER_DEFINED + 1, "function not implemented");
EXC_DEFINE(stack_overflow, EXC_NUM_USER_DEFINED + 2, "stack overflow");
EXC_DEFINE(stack_underflow, EXC_NUM_USER_DEFINED + 3, "stack underflow");

void stackInitialize(Stack * stack) {
  unsigned int i;
  if(NULL == stack) {
    printf("Stack::init stack is NULL");
    exit(-1);    
  }
  stack->top = STACK_EMPTY_INDEX;
  for(i=0; i<STACK_CAPACITY; i++) {
    stack->buffer[i].id = 0;
    stack->buffer[i].name[0] = '\x0';
  }
}

/**
  Funkcja PUSH, K.2.4 str. 37 w skrypcie
*/
void push(Stack * stack, const Finger * finger) EXC_THROWS(stack_overflow) {
  //usuń albo zakomentuj tę instrukcję
  EXC_THROW(stack_function_not_implemented);
  // Sprawdź, czy stos się nie przepełni, gdy dodamy element.
  //jeżeli stos się przepełni, to zwróć błąd w taki sposób:
  /*
  if(wykryto_przepełnienie_stosu) {
    EXC_THROW(stack_overflow);
  }
*/
}

/**
  Funkcja POP, K.2.5 str. 38 w skrypcie
*/
Finger * pop(Stack * stack) EXC_THROWS(stack_underflow) {
  //usuń albo zakomentuj tę instrukcję
  EXC_THROW(stack_function_not_implemented);

  // Sprawdź, czy stos jest pusty (użyj funkcji isStackEmpty).
  //jeżeli stos jest pusty, to zwróć błąd w taki sposób:
  /*
  if(wykryto_pusty_stos) {
    EXC_THROW(stack_underflow);
  }
*/
}

/**
  Funkcja STOS-PUSTY, K.2.6 str. 38 w skrypcie
*/
bool isStackEmpty(const Stack * stack) {
  if(STACK_EMPTY_INDEX == stack->top) {
    return true;
  } else {
    return false;
  }
}
