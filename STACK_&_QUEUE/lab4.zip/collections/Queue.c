#include <stdio.h>
#include <stdlib.h>
#include "Queue.h"
#include "../exception/excdefs.h"
#include "../exception/exception.h"

EXC_DEFINE(queue_function_not_implemented, EXC_NUM_USER_DEFINED + 10, "function not implemented");
EXC_DEFINE(queue_overflow, EXC_NUM_USER_DEFINED + 11, "queue overflow");
EXC_DEFINE(queue_underflow, EXC_NUM_USER_DEFINED + 12, "queue underflow");

void queueInitialize(Queue * queue) {
  unsigned int i, n;
  
  if(NULL == queue) {
    printf("Queue::init queue is NULL");
    exit(-1);    
  }
  queue->head = QUEUE_FIRST_INDEX;
  queue->tail = QUEUE_FIRST_INDEX;
  n = sizeof(queue->buffer)/sizeof(queue->buffer[0]);
  for(i=0; i<n; i++) {
    queue->buffer[i].id = 0;
    queue->buffer[i].name[0] = '\x0';
  }
}

void enqueue(Queue * queue, const Finger * finger) {
  //usuń albo zakomentuj tę instrukcję
  EXC_THROW(queue_function_not_implemented);
  // sprawdź, czy kolejka nie nadpisuje, gdy dodamy element
  // jeżeli nadpisujesz, zwróć błąd w taki sposób:
  /*
  if(wykryto_nadpisywanie) {
    EXC_THROW(queue_overflow);
  }
    */

}


Finger * dequeue(Queue * queue) {
  /**
  * element kolejki, który będzie zwrócony z funkcji
  */
  Finger * element;
  
  //usuń albo zakomentuj tę instrukcję
  EXC_THROW(queue_function_not_implemented);
  //sprawdź, czy kolejka ma jakiś element, zanim zwrócisz element
  // jeżeli kolejka jest pusta, zwróć błąd w taki sposób:
  /*
  if(wykryto_pustą_kolejkę) {
    EXC_THROW(queue_underflow);
  }
    */

  return element;
}

