/** 
  Test stosu.
*/
#ifndef TEST_STACK_1FDI_PRZ
#define TEST_STACK_1FDI_PRZ

#include "../collections/Stack.h"

void testStack();

#endif
