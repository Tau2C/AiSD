#ifndef TEST_DATATYPES_1FDI_PRZ
#define TEST_DATATYPES_1FDI_PRZ

#include "../dataTypes/DataTypes.h"

void createFingers(Finger * fingers);
void printFingerInfo(const Finger * finger);

#endif
