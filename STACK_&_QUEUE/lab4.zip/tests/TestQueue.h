/** 
  Test kolejki.
*/
#ifndef TEST_QUEUE_1FDI_PRZ
#define TEST_QUEUE_1FDI_PRZ

#include "../collections/Queue.h"

void testQueue();

#endif
